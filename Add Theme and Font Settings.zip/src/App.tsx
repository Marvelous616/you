import { FormEvent, useLayoutEffect, useMemo, useState } from "react";

type View = "today" | "review" | "settings";
type Theme = "light" | "dark";

type Suggestion = {
  id: number;
  title: string;
  time: string;
  confidence: string;
};

const hours = Array.from({ length: 16 }, (_, index) => `${String(index + 7).padStart(2, "0")}:00`);

const initialSuggestions: Suggestion[] = [
  { id: 1, title: "Team standup", time: "10:00–10:15", confidence: "0.9" },
  { id: 2, title: "Dentist appointment", time: "19:00–19:45", confidence: "0.9" },
  { id: 3, title: "Project sync with Dev", time: "20:00–20:30", confidence: "0.7" },
];

const timelineEvents = [
  {
    top: 30,
    height: 26,
    left: 0,
    width: 100,
    color: "#e0b457",
    title: "Breakfast",
    meta: "07:30–08:00",
    compact: true,
  },
  {
    top: 114,
    height: 194,
    left: 0,
    width: 62,
    color: "#68a0eb",
    title: "Refactor sync outbox",
    meta: "work/coding · 09:00–12:30 · live",
  },
  {
    top: 142,
    height: 40,
    left: 64,
    width: 36,
    color: "#5ec4b2",
    title: "Podcast",
    meta: "learning · 09:30–10:15",
  },
  {
    top: 324,
    height: 42,
    left: 0,
    width: 100,
    color: "#e0b457",
    title: "Lunch with Ravi",
    meta: "food/lunch · 12:45–13:30",
  },
  {
    top: 394,
    height: 68,
    left: 0,
    width: 100,
    color: "#78c482",
    title: "Gym",
    meta: "health/exercise · 14:00–15:15 · backfill",
  },
  {
    top: 534,
    height: 28,
    left: 0,
    width: 100,
    color: "#b08ce6",
    title: "Call with Priya",
    meta: "16:30–17:00",
    compact: true,
  },
  {
    top: 568,
    height: 52,
    left: 0,
    width: 100,
    color: "#68a0eb",
    title: "Write web design notes",
    meta: "work/docs · 17:00–18:00",
  },
];

function Button({
  children,
  primary = false,
  onClick,
  type = "button",
  className = "",
}: {
  children: React.ReactNode;
  primary?: boolean;
  onClick?: () => void;
  type?: "button" | "submit";
  className?: string;
}) {
  return (
    <button
      className={`button ${primary ? "button--primary" : ""} ${className}`}
      onClick={onClick}
      type={type}
    >
      {children}
    </button>
  );
}

function Nav({
  view,
  setView,
  pending,
}: {
  view: View;
  setView: (view: View) => void;
  pending: number;
}) {
  const navItems = [
    { label: "Today", view: "today" as const },
    { label: "Inbox", badge: pending },
    { label: "End-of-day review", view: "review" as const },
    { label: "Days" },
    { label: "Tags and people" },
    { label: "Extensions" },
    { label: "Settings", view: "settings" as const },
  ];

  return (
    <nav className="sidebar" aria-label="Main navigation">
      <button className="brand" onClick={() => setView("today")}>
        Life Logger
      </button>
      <div className="nav-list">
        {navItems.map((item) => (
          <button
            className={`nav-item ${item.view === view ? "nav-item--active" : ""}`}
            key={item.label}
            onClick={() => item.view && setView(item.view)}
          >
            <span>{item.label}</span>
            {item.badge !== undefined && item.badge > 0 && (
              <span className="badge">{item.badge}</span>
            )}
          </button>
        ))}
      </div>
      <div className="connection">
        <span className="connection-dot" /> Local server connected
      </div>
    </nav>
  );
}

function Today({
  suggestions,
  removeSuggestion,
  journal,
  setJournal,
  setView,
}: {
  suggestions: Suggestion[];
  removeSuggestion: (id: number, action: string) => void;
  journal: string;
  setJournal: (value: string) => void;
  setView: (view: View) => void;
}) {
  const [entry, setEntry] = useState("");
  const [logged, setLogged] = useState<string[]>([]);
  const [notice, setNotice] = useState("");
  const [filledGaps, setFilledGaps] = useState<number[]>([]);

  const parsed = useMemo(() => {
    if (!entry.trim()) return ["title: lunch with Ravi", "12:45 – 13:30", "food/lunch", "Ravi"];
    const tags = entry.match(/#[\w/-]+/g)?.map((tag) => tag.slice(1)) ?? [];
    const people = entry.match(/@[\w-]+/g)?.map((person) => person.slice(1)) ?? [];
    const time = entry.match(/\d{1,2}:\d{2}\s*[-–]\s*\d{1,2}:\d{2}/)?.[0];
    const title = entry
      .replace(/#[\w/-]+|@[\w-]+|\d{1,2}:\d{2}\s*[-–]\s*\d{1,2}:\d{2}/g, "")
      .trim();
    return [
      `title: ${title || "untitled event"}`,
      ...(time ? [time.replace("-", " – ")] : []),
      ...tags,
      ...people,
    ];
  }, [entry]);

  function logEvent(event: FormEvent) {
    event.preventDefault();
    if (!entry.trim()) {
      setNotice("Enter an event first.");
      return;
    }
    setLogged((items) => [...items, entry.trim()]);
    setEntry("");
    setNotice("Event logged.");
  }

  function markNow() {
    const time = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
    setNotice(`Marker saved at ${time}.`);
  }

  function fillGap(gap: number) {
    setFilledGaps((items) => [...items, gap]);
    setNotice("Gap marked for review.");
  }

  return (
    <div className="today-layout">
      <main className="today-main">
        <header className="day-header">
          <div>
            <p className="eyebrow">Today</p>
            <h1>Sunday, 15 November 2026</h1>
            <p className="muted day-meta">
              Asia/Kolkata <span>·</span> Review: in progress
            </p>
          </div>
          <div className="status-chips">
            <span className="chip">
              Wake <b>07:10</b>
            </span>
            <span className="chip">
              Sleep <b>not set</b>
            </span>
            <span className="chip">Fidelity: detailed</span>
            <span className="chip">
              Coverage <b>78%</b>
            </span>
          </div>
        </header>

        <form className="quick-entry" onSubmit={logEvent}>
          <div className="entry-input-wrap">
            <span className="entry-symbol">+</span>
            <input
              aria-label="Quick entry"
              onChange={(event) => setEntry(event.target.value)}
              placeholder="lunch with Ravi 12:45-13:30 #food/lunch @Ravi"
              value={entry}
            />
          </div>
          <Button primary type="submit">
            Log event
          </Button>
          <Button onClick={markNow}>Mark now</Button>
        </form>
        <div className="parsed-row" aria-live="polite">
          <span className="parsed-label">{notice || "Parsed:"}</span>
          {!notice &&
            parsed.map((item) => (
              <span className="chip" key={item}>
                {item}
              </span>
            ))}
        </div>

        <section className="timeline" aria-label="Timeline for today">
          <div className="hour-labels">
            {hours.map((hour) => (
              <div className="hour" key={hour}>
                {hour}
              </div>
            ))}
          </div>
          <div className="track">
            <div className="marker" style={{ top: 8 }}>
              <i />
              Woke up <span>· 07:10</span>
            </div>
            {timelineEvents.map((item) => (
              <div
                className={`timeline-event ${item.compact ? "timeline-event--compact" : ""}`}
                key={item.title}
                style={{
                  top: item.top,
                  height: item.height,
                  left: `${item.left}%`,
                  width: `${item.width}%`,
                  background: `color-mix(in srgb, ${item.color} 16%, transparent)`,
                  borderLeftColor: item.color,
                }}
              >
                <span className="event-title">
                  <i style={{ background: item.color }} />
                  {item.title}
                </span>
                <small>{item.meta}</small>
              </div>
            ))}
            {!filledGaps.includes(1) && (
              <div className="gap" style={{ top: 60, height: 52 }}>
                <span>
                  <b>Untracked</b> 08:00–09:00
                </span>
                <Button onClick={() => fillGap(1)}>Fill gap</Button>
              </div>
            )}
            {!filledGaps.includes(2) && (
              <div className="gap" style={{ top: 466, height: 64 }}>
                <span>
                  <b>Untracked</b> 15:15–16:30
                </span>
                <Button onClick={() => fillGap(2)}>Fill gap</Button>
              </div>
            )}
            <div className="marker marker--offset" style={{ top: 222 }}>
              <i />
              Headache <span>· 11:05</span>
            </div>
            {logged.map((item, index) => (
              <div
                className="timeline-event added-event"
                key={`${item}-${index}`}
                style={{ top: 630 + index * 46 }}
              >
                <span className="event-title">
                  <i />
                  {item}
                </span>
                <small>just added · backfill</small>
              </div>
            ))}
            <div className="now-line" style={{ top: 650 + logged.length * 46 }}>
              <span>now 18:20</span>
            </div>
          </div>
        </section>
      </main>

      <aside className="right-panel" aria-label="Day details">
        <section>
          <div className="section-heading">
            <h2>Suggestions</h2>
            <span>{suggestions.length} pending</span>
          </div>
          <div className="panel-card suggestion-list">
            {suggestions.length ? (
              suggestions.map((suggestion) => (
                <article className="suggestion" key={suggestion.id}>
                  <div className="suggestion-heading">
                    <i />
                    <h3>{suggestion.title}</h3>
                  </div>
                  <p>
                    Calendar import · <span>{suggestion.time}</span> · confidence{" "}
                    {suggestion.confidence}
                  </p>
                  <div className="button-row">
                    <Button primary onClick={() => removeSuggestion(suggestion.id, "accepted")}>
                      Accept
                    </Button>
                    <Button onClick={() => setNotice(`${suggestion.title} is ready to edit.`)}>
                      Edit
                    </Button>
                    <Button onClick={() => removeSuggestion(suggestion.id, "rejected")}>
                      Reject
                    </Button>
                  </div>
                </article>
              ))
            ) : (
              <p className="empty-state">Inbox cleared. No pending suggestions.</p>
            )}
          </div>
          <Button className="full-button">Import .ics file</Button>
        </section>

        <section>
          <div className="section-heading">
            <h2>Markers today</h2>
            <span>2</span>
          </div>
          <div className="panel-card markers-card">
            <div>
              <span>Woke up</span>
              <b>07:10</b>
            </div>
            <div>
              <span>Headache</span>
              <b>11:05</b>
            </div>
          </div>
        </section>

        <section>
          <div className="section-heading">
            <h2>Journal</h2>
            <span>Auto-saved</span>
          </div>
          <label className="field-label" htmlFor="today-journal">
            Reflection for today
          </label>
          <textarea
            id="today-journal"
            onChange={(event) => setJournal(event.target.value)}
            placeholder="How did the day go?"
            value={journal}
          />
          <div className="button-row journal-actions">
            <Button onClick={() => setNotice("Journal saved.")}>Save journal</Button>
            <Button primary onClick={() => setView("review")}>
              Complete review
            </Button>
          </div>
        </section>
      </aside>
    </div>
  );
}

function Review({
  journal,
  setJournal,
  resolved,
  setResolved,
  setView,
}: {
  journal: string;
  setJournal: (value: string) => void;
  resolved: number[];
  setResolved: (value: number[]) => void;
  setView: (view: View) => void;
}) {
  const [sleep, setSleep] = useState("23:30");
  const [complete, setComplete] = useState(false);
  const stats = [
    ["Events logged", "9", "Across 7 categories"],
    ["Tracked time", "9h 40m", "78% of your day"],
    [
      "Open gaps",
      String(2 - resolved.length),
      resolved.length ? "Review in progress" : "2h 15m untracked",
    ],
    ["Fidelity", "Detailed", "Good coverage"],
  ];
  const tags = [
    ["work", "4h 30m", 75, "#68a0eb"],
    ["health", "1h 15m", 21, "#78c482"],
    ["food", "1h 15m", 21, "#e0b457"],
    ["learning", "45m", 12, "#5ec4b2"],
  ];
  const gaps = [
    ["08:00 – 09:00", "60 minutes untracked"],
    ["15:15 – 16:30", "75 minutes untracked"],
  ];

  return (
    <main className="review-main">
      <header className="review-header">
        <div>
          <p className="eyebrow">Daily reflection</p>
          <h1>{complete ? "Review complete" : "End-of-day review"}</h1>
          <p className="muted">
            Sunday, 15 November 2026 <span>·</span> four short steps
          </p>
        </div>
        <div className="review-progress" aria-label="Review steps">
          {["Coverage", "Gaps", "Sleep", "Journal"].map((step, index) => (
            <span className={index <= (resolved.length ? 2 : 1) ? "done" : ""} key={step}>
              <i>{index + 1}</i>
              {step}
            </span>
          ))}
        </div>
      </header>

      {complete && (
        <div className="success-card">
          <div>
            <span className="success-check">✓</span>
            <div>
              <h2>Sunday is in the books.</h2>
              <p>Your timeline and reflection have been saved.</p>
            </div>
          </div>
          <Button onClick={() => setView("today")}>Back to today</Button>
        </div>
      )}

      <section className="stat-grid">
        {stats.map(([label, value, detail]) => (
          <div className="stat-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
            <small>{detail}</small>
          </div>
        ))}
      </section>

      <section className="review-section">
        <div className="section-title">
          <span>01</span>
          <div>
            <h2>Time by tag</h2>
            <p>How your tracked time was distributed</p>
          </div>
        </div>
        <div className="review-card tag-card">
          {tags.map(([label, value, width, color]) => (
            <div className="tag-row" key={label}>
              <div>
                <span>
                  <i style={{ background: color }} />
                  {label}
                </span>
                <b>{value}</b>
              </div>
              <div className="bar">
                <i style={{ width: `${width}%`, background: color }} />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="review-section">
        <div className="section-title">
          <span>02</span>
          <div>
            <h2>Gaps to resolve</h2>
            <p>Account for the blank spaces in your day</p>
          </div>
        </div>
        <div className="review-card gap-card">
          {gaps.map(([time, detail], index) => (
            <div
              className={`gap-row ${resolved.includes(index) ? "gap-row--resolved" : ""}`}
              key={time}
            >
              <div>
                <strong>{time}</strong>
                <span>{resolved.includes(index) ? "Resolved" : detail}</span>
              </div>
              {!resolved.includes(index) && (
                <div className="button-row">
                  <Button onClick={() => setResolved([...resolved, index])}>Add event</Button>
                  <Button onClick={() => setResolved([...resolved, index])}>Mark as nothing</Button>
                </div>
              )}
              {resolved.includes(index) && <span className="resolved-label">Done</span>}
            </div>
          ))}
        </div>
      </section>

      <section className="review-section">
        <div className="section-title">
          <span>03</span>
          <div>
            <h2>Sleep and journal</h2>
            <p>Close out the day with a final reflection</p>
          </div>
        </div>
        <div className="review-card reflection-card">
          <div className="sleep-field">
            <label htmlFor="sleep">Sleep time</label>
            <input
              id="sleep"
              onChange={(event) => setSleep(event.target.value)}
              type="time"
              value={sleep}
            />
            <small>Your day will end here</small>
          </div>
          <div className="journal-field">
            <label htmlFor="review-journal">Journal</label>
            <textarea
              id="review-journal"
              onChange={(event) => setJournal(event.target.value)}
              placeholder="What stood out today? What state were you in?"
              value={journal}
            />
            <small>{journal.length} characters</small>
          </div>
        </div>
      </section>

      <footer className="review-actions">
        <p>Everything can still be edited after you finish.</p>
        <div className="button-row">
          <Button onClick={() => setView("today")}>Save and finish later</Button>
          <Button primary onClick={() => setComplete(true)}>
            Complete review
          </Button>
        </div>
      </footer>
    </main>
  );
}

function ThemeIcon({ theme }: { theme: Theme }) {
  return theme === "light" ? (
    <svg aria-hidden="true" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="3.5" />
      <path d="M12 2v2.2M12 19.8V22M4.9 4.9l1.6 1.6M17.5 17.5l1.6 1.6M2 12h2.2M19.8 12H22M4.9 19.1l1.6-1.6M17.5 6.5l1.6-1.6" />
    </svg>
  ) : (
    <svg aria-hidden="true" viewBox="0 0 24 24">
      <path d="M20 15.6A8.7 8.7 0 0 1 8.4 4a8.7 8.7 0 1 0 11.6 11.6Z" />
    </svg>
  );
}

function Settings({ theme, setTheme }: { theme: Theme; setTheme: (theme: Theme) => void }) {
  const isDark = theme === "dark";

  return (
    <main className="settings-main">
      <header className="settings-header">
        <p className="eyebrow">Personalize your space</p>
        <h1>Settings</h1>
        <p className="muted">Shape Life Logger around the way you work and reflect.</p>
      </header>

      <section className="settings-section" aria-labelledby="appearance-heading">
        <div className="settings-section-title">
          <span>01</span>
          <div>
            <h2 id="appearance-heading">Appearance</h2>
            <p>Choose the atmosphere that feels most comfortable.</p>
          </div>
        </div>

        <div className="settings-card">
          <div className="setting-copy">
            <h3>Color theme</h3>
            <p>Your selection is saved on this device.</p>
          </div>
          <div className="theme-options" role="radiogroup" aria-label="Color theme">
            {(["light", "dark"] as const).map((option) => (
              <button
                aria-checked={theme === option}
                className={`theme-option ${theme === option ? "theme-option--active" : ""}`}
                key={option}
                onClick={() => setTheme(option)}
                role="radio"
                type="button"
              >
                <span className={`theme-preview theme-preview--${option}`}>
                  <i />
                  <b />
                  <em />
                </span>
                <span className="theme-option-label">
                  <ThemeIcon theme={option} />
                  {option === "light" ? "Light" : "Dark"}
                  <i className="radio-mark" />
                </span>
              </button>
            ))}
          </div>

          <div className="toggle-row">
            <span className="toggle-icon">
              <ThemeIcon theme="dark" />
            </span>
            <div>
              <h3>Dark mode</h3>
              <p>Reduce brightness for evening reflection.</p>
            </div>
            <button
              aria-checked={isDark}
              aria-label="Toggle dark mode"
              className={`switch ${isDark ? "switch--on" : ""}`}
              onClick={() => setTheme(isDark ? "light" : "dark")}
              role="switch"
              type="button"
            >
              <span />
            </button>
          </div>
        </div>
      </section>

      <section className="settings-section" aria-labelledby="type-heading">
        <div className="settings-section-title">
          <span>02</span>
          <div>
            <h2 id="type-heading">Typography</h2>
            <p>A unified monospaced system with an expanded Nerd Font glyph set.</p>
          </div>
        </div>
        <div className="settings-card type-showcase">
          <div>
            <span className="type-sample">Aa</span>
            <div>
              <h3>JetBrains Mono NL</h3>
              <p>Primary face · headings, journals, and interface copy</p>
            </div>
          </div>
          <div>
            <span className="type-sample type-sample--sans">&lt;/&gt;</span>
            <div>
              <h3>Nerd Font Mono</h3>
              <p>Expanded glyph set · symbols remain aligned to the grid</p>
            </div>
          </div>
          <div>
            <span className="type-sample type-sample--mono">08</span>
            <div>
              <h3>Monospaced rhythm</h3>
              <p>Data face · time, tags, and timeline details</p>
            </div>
          </div>
        </div>
      </section>

      <p className="settings-note" aria-live="polite">
        Changes apply instantly and are saved automatically.
      </p>
    </main>
  );
}

export default function App() {
  const [view, setView] = useState<View>("today");
  const [suggestions, setSuggestions] = useState(initialSuggestions);
  const [journal, setJournal] = useState("");
  const [resolved, setResolved] = useState<number[]>([]);
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem("life-logger-theme");
    if (saved === "light" || saved === "dark") return saved;
    return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  });

  useLayoutEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    localStorage.setItem("life-logger-theme", theme);
  }, [theme]);

  function removeSuggestion(id: number, _action: string) {
    setSuggestions((items) => items.filter((item) => item.id !== id));
  }

  return (
    <div className="app-shell">
      <Nav pending={suggestions.length} setView={setView} view={view} />
      {view === "today" ? (
        <Today
          journal={journal}
          removeSuggestion={removeSuggestion}
          setJournal={setJournal}
          setView={setView}
          suggestions={suggestions}
        />
      ) : view === "review" ? (
        <Review
          journal={journal}
          resolved={resolved}
          setJournal={setJournal}
          setResolved={setResolved}
          setView={setView}
        />
      ) : (
        <Settings setTheme={setTheme} theme={theme} />
      )}
    </div>
  );
}
